package com.example.kopiujwklej;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText edit1, edit2;
    private Button btn1, btn2;
    private ClipboardManager clipboardManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btn3 = findViewById(R.id.btn3);
        edit3 = findViewById(R.id.edit3);

//        edit1 = findViewById(R.id.edit1);
//        edit2 = findViewById(R.id.edit2);
//        btn1 = findViewById(R.id.btn1);
//        btn2 = findViewById(R.id.btn2);

//        clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
//
//        btn1.setOnClickListener(view -> {
//            String textToCopy = edit1.getText().toString();
//            if(!textToCopy.isEmpty()){
//                ClipData clipData = ClipData.newPlainText("text", textToCopy);
//                clipboardManager.setPrimaryClip(clipData);
//                Toast.makeText(this, "skopiowano do schowka", Toast.LENGTH_LONG).show();
//            }else{
//                Toast.makeText(this, "problem ze skopiowaniem do schowka", Toast.LENGTH_LONG).show();
//            }
//        });
//
//        btn2.setOnClickListener(view -> {
//            if(clipboardManager.hasPrimaryClip() &&
//                    clipboardManager.getPrimaryClipDescription().hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)){
//                ClipData.Item item = clipboardManager.getPrimaryClip().getItemAt(0);
//                String textToPaste = item.getText().toString();
//                edit2.setText(textToPaste);
//                Toast.makeText(this, "wklejono ze schowka", Toast.LENGTH_LONG).show();
//            }else{
//                Toast.makeText(this, "problem z wklejeniem ze schowka", Toast.LENGTH_LONG).show();
//            }
//        });



    }
}