package com.example.wczytajobrazy;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    Button btnPickImage;
    LinearLayout imageContainer;

    //deklaracja listy obrazkow w drawable

    private final int[] IMAGE_IDS = new int[]{
      R.drawable.audi1,
      R.drawable.audi2,
      R.drawable.audi3,
      R.drawable.audi4
    };

    //lista nazw obrazkow
    private final String[] IMAGE_NAMES = new String[]{
      "audi1", "audi2", "audi3", "audi4"
    };

    //lista zaznaczonych obrazkow na wyskakujacym alercie
    private boolean[] selected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

            btnPickImage = findViewById(R.id.btnPickImage);
            imageContainer = findViewById(R.id.imageContainer);

            //poczatkowa ilosc true/false w liscie zaznaczonych
            selected = new boolean[IMAGE_NAMES.length];

            //nasluch na buttona

            btnPickImage.setOnClickListener(v -> showPickDialog());
    }

    //metoda wyswietla alert dialog do wyboru zdjec
    private void showPickDialog(){
        new AlertDialog.Builder(this).
                setTitle("@string/alertText").
                setMultiChoiceItems(IMAGE_NAMES, selected, (dialog, which, isChecked) ->
                    {selected[which] = isChecked;}).
                setPositiveButton("OK", (dialog, which) -> displayImages()).
                setNegativeButton("Anuluj", null).
                show();
    }

    //Metoda wyswietlajaca obrazki
    private void displayImages(){
        imageContainer.removeAllViews();
        for (int i=0;i<IMAGE_IDS.length;i++){
            if (selected[i]){
                ImageView iv = new ImageView(this);
                iv.setAdjustViewBounds(true);
                iv.setImageResource(IMAGE_IDS[i]);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                  LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

                iv.setLayoutParams(lp);
                imageContainer.addView(iv);
            }
        }
    }

}