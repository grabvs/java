import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.R;
import com.example.myapplication.SummaryActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText editName;
    RadioGroup radioProcesor, radioKarta;
    RadioButton radioIntel, radioAmd, radioRtx, radioRadeon;
    CheckBox cboxMysz, cboxKlawiatura, cboxMonitor;
    Spinner spinnerSSD;
    Button btnZamow;

    private List<String> spinnerItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicjalizacja komponentów
        editName = findViewById(R.id.editName);
        radioProcesor = findViewById(R.id.radioProcesor);
        radioKarta = findViewById(R.id.radioKarta);
        radioIntel = findViewById(R.id.radioIntel);
        radioAmd = findViewById(R.id.radioAmd);
        radioRtx = findViewById(R.id.radioRtx);
        radioRadeon = findViewById(R.id.radioRadeon);
        cboxMysz = findViewById(R.id.cboxMysz);
        cboxKlawiatura = findViewById(R.id.cboxKlawiatura);
        cboxMonitor = findViewById(R.id.cboxMonitor);
        spinnerSSD = findViewById(R.id.spinnerSSD);
        btnZamow = findViewById(R.id.btnZamow);

        // Spinner z List<String>
        spinnerItems = Arrays.asList("256 GB (150 zł)", "512 GB (250 zł)", "1 TB (400 zł)", "2 TB (600 zł)");
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, spinnerItems);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerSSD.setAdapter(adapter);

        btnZamow.setOnClickListener(v -> {
            String name = editName.getText().toString().trim();

            if (name.isEmpty()) {
                Toast.makeText(this, "Wpisz imię i nazwisko!", Toast.LENGTH_SHORT).show();
                return;
            }

            int selectedProcessorId = radioProcesor.getCheckedRadioButtonId();
            int selectedGPUId = radioKarta.getCheckedRadioButtonId();

            if (selectedProcessorId == -1) {
                Toast.makeText(this, "Wybierz procesor!", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedGPUId == -1) {
                Toast.makeText(this, "Wybierz kartę graficzną!", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton selectedProcessor = findViewById(selectedProcessorId);
            RadioButton selectedGPU = findViewById(selectedGPUId);
            String ssd = spinnerSSD.getSelectedItem().toString();

            ArrayList<String> summaryList = new ArrayList<>();
            int totalPrice = 0;

            summaryList.add("Zamawiający: " + name);
            summaryList.add("Procesor: " + selectedProcessor.getText());
            totalPrice += selectedProcessor == radioIntel ? 800 : 750;

            summaryList.add("Karta graficzna: " + selectedGPU.getText());
            totalPrice += selectedGPU == radioRtx ? 1500 : 1400;

            if (cboxMysz.isChecked()) {
                summaryList.add("Dodatki: Myszka gamingowa");
                totalPrice += 100;
            }
            if (cboxKlawiatura.isChecked()) {
                summaryList.add("Dodatki: Klawiatura mechaniczna");
                totalPrice += 200;
            }
            if (cboxMonitor.isChecked()) {
                summaryList.add("Dodatki: Monitor 24 cale");
                totalPrice += 600;
            }

            summaryList.add("Dysk SSD: " + ssd);
            if (ssd.contains("150")) totalPrice += 150;
            else if (ssd.contains("250")) totalPrice += 250;
            else if (ssd.contains("400")) totalPrice += 400;
            else if (ssd.contains("600")) totalPrice += 600;

            summaryList.add("Suma: " + totalPrice + " zł");

            Intent intent = new Intent(MainActivity.this, SummaryActivity.class);
            intent.putStringArrayListExtra("summaryList", summaryList);
            startActivity(intent);
        });
    }
}
